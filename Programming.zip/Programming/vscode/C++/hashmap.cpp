#include<iostream>
#include<map>
#include<unordered_map>
using namespace std;
int main(){
unordered_map<string,int> m;

pair<string,int> p =make_pair("Asrar",4);
m.insert(p);

pair<string,int> pair2("Ul",3);
m.insert(pair2);

m["Haq"]=2;

m["Haq"]=1;

//search
cout<<m["Asrar"]<<endl;

cout<<m.at("Haq")<<endl;

//size
cout<<"size is "<<m.size()<<endl;

//presence
cout<<"check presence "<<m.count("Asrar")<<endl;
cout<<"check presence "<<m.count("unknown")<<endl;

//erase
m.erase("Haq");
cout<<"size is "<<m.size()<<endl;

//iterator
unordered_map<string,int>  :: iterator it=m.begin();
while(it!=m.end()){
    cout<<it->first<<" "<<it->second<<endl;
    it++;
}
    return 0;
}