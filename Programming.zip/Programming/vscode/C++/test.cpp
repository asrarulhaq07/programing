#include <bits/stdc++.h>
using namespace std;
int solve(vector<int> arr, int n)
{
    sort(arr.begin(), arr.end());
    int sum1 = 0;
    int sum2 = 0;
    for (int i = 0; i < n; i++)
    {
        if (arr[i] <= 0)
        {
            sum1 += arr[i];
        }
        else
        {
            sum2 += arr[i];
        }
    }
    return abs(abs(sum1) - abs(sum2));
}

int main()
{

    int t;
    cin >> t;
    while (t--)
    {

        int n;
        cin >> n;
        vector<int> arr;
        for (int i = 0; i < n; i++)
        {
            int c;
            cin >> c;
            arr.push_back(c);
        }

        cout << solve(arr, n);
    }

    return 0;
}