//BFS Algorithm

#include <iostream>
#include <queue>
using namespace std;

vector<vector<int>> BFS(vector<vector<int>> graph, int start)
{
    vector<vector<int>> result;
    vector<int> visited(graph.size(), 0);
    queue<int> q;
    q.push(start);
    visited[start] = 1;
    while (!q.empty())
    {
        int node = q.front();
        q.pop();
        vector<int> temp;
        temp.push_back(node);
        for (int i = 0; i < graph[node].size(); i++)
        {
            if (visited[graph[node][i]] == 0)
            {
                q.push(graph[node][i]);
                visited[graph[node][i]] = 1;
            }
        }
        result.push_back(temp);
    }
    return result;
}

int main()
{
    vector<vector<int>> graph = {{1, 2}, {0, 2, 3}, {0, 1, 3}, {1, 2}};
    vector<vector<int>> result = BFS(graph, 0);
    for (int i = 0; i < result.size(); i++)
    {
        for (int j = 0; j < result[i].size(); j++)
        {
            cout << result[i][j] << " ";
        }
        cout << endl;
    }
    return 0;
}