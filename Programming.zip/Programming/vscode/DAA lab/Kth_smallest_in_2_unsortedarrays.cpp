//kth smallest element in two unsorted arrays
#include <bits/stdc++.h>
using namespace std;
void print(vector<int> v){
    for(int i=0;i<v.size();i++){
        cout<<v[i]<<" ";
    }
    cout<<endl;
}
// void union_array(vector<int> &v1,vector<int> &v2){
//     v1=v1+v2;
// }

int main(){
    int n,m,k;
    cout<<"Enter the size of the first array: ";
    cin>>n;
    vector<int> v1,v2;
    cout<<"Enter the elements of first array: ";
    for(int i=0;i<n;i++){
        int x;
        cin>>x;
        v1.push_back(x);
    }
    cout<<"Enter the size of the second array: ";
    cin>>m;
    cout<<"Enter the elements of second array: ";
    for(int i=0;i<m;i++){
        int x;
        cin>>x;
        v2.push_back(x);
    }
    cout<<"Enter the value of k: ";
    cin>>k;
    cout<<"The arrays are: "<<endl;
    print(v1);
    print(v2);
    //union_array(v1,v2);
    print(v1);
    return 0;
}