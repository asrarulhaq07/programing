//MCM
#include<bits/stdc++.h>
using namespace std;

int MCM(int arr[],int i,int j)
{
    if(i>=j)
        return 0;
    int min=INT_MAX;
    for(int k=i;k<=j-1;k++)
    {
        int temp=MCM(arr,i,k)+MCM(arr,k+1,j)+arr[i-1]*arr[k]*arr[j];
        if(temp<min)
            min=temp;
    }
    return min;
}

int main()
{
    int n;
    cout<<"Enter the number of matrices: ";
    cin>>n;
    int arr[n];
    cout<<"Enter the dimensions of the matrices: ";
    for(int i=0;i<n;i++)
        cin>>arr[i];
    cout<<"Minimum number of multiplications: "<<MCM(arr,1,n);
    return 0;
}