//Max subsequence
#include<bits/stdc++.h>
using namespace std;
int solve(vector<int> &arr,int s,int mid,int e){
        int sum=0;
        int left_sum=INT_MIN;
        for(int i=mid;i>=s;i--){
            sum+=arr[i];
            if(sum>left_sum)
                left_sum=sum;   
        }
            sum=0;
            int right_sum=INT_MIN;
            for(int i=mid;i<=e;i++){
                sum+=arr[i];
                if(sum>right_sum)
                    right_sum=sum;
            }
        return max(max(left_sum+right_sum-arr[mid],left_sum),right_sum);
}

int maxsum(vector<int> & arr,int s,int e){
    if(s>e){
        return INT_MIN;
    }
    if(s==e){
        return arr[s];
    }
    int mid=(s+e)/2;
    return max(max(maxsum(arr,s,mid-1),maxsum(arr,mid+1,e)),solve(arr,s,mid,e));

}
void print(vector<int> arr, int n)
{
    for(int i=0;i<n;i++){
        cout<<arr[i]<<" ";
    }cout<<endl;
}

int main(){
int n;
cin>>n;
vector<int> arr;
for(int i=0;i<n;i++){
    int val=rand()%10;
    arr.push_back(val);
}
print(arr,n);
cout<<maxsum(arr,0,n);
    return 0;
}