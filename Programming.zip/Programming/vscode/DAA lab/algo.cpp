#include<bits/stdc++.h>
using namespace std;
void print(vector<int> arr, int n)
{
    for(int i=0;i<n;i++){
        cout<<arr[i]<<" ";
    }cout<<endl;
}
void solve(vector<int> &arr,int n,int s,int e){

    if(n==2 && arr[s]>arr[s+1] ){
        swap(arr[0],arr[1]);
        return;
    }
    else if(n>2){
       int  m=(2*n)/3+1;
       solve(arr,n,0,m-1);
       solve(arr,n,n-m,n-1);
       solve(arr,n,0,m-1);
    }
}

int main(){

    int n;
    cin>>n;
    vector<int> arr;
    for(int i=0;i<n;i++){
        int val;
        cin>> val;
        arr.push_back(val);
    }
    solve(arr,n-1,0,n-1);
    print(arr,n);

    return 0;
}
