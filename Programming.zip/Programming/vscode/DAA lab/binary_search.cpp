//binary search
#include <bits/stdc++.h>
using namespace std;

int binary_search(vector<int> v,int key){
    int low=0;
    int high=v.size()-1;
    while(low<=high){
        int mid=(low+high)/2;
        if(v[mid]==key){
            return mid;
        }
        else if(v[mid]<key){
            low=mid+1;
        }
        else{
            high=mid-1;
        }
    }
    return -1;
}
int main(){
    int n;
    cin>>n;
    vector<int> v(n);
    for(int i=0;i<n;i++){
        cin>>v[i];
    }
    int key;
    cin>>key;
    int index=binary_search(v,key);
    if(index==-1){
        cout<<"Not found"<<endl;
    }
    else{
        cout<<"Found at index "<<index<<endl;
    }
    return 0;
}