//Depth First Search
#include <bits/stdc++.h>

using namespace std;

void DepthFirstSearch(vector<vector<int>> graph, int i,unordered_map<int,int> &mp)
{
   mp[i] = 1;
   for(auto i:graph[i])
   {
       if(mp[i]==0)
       {
           DepthFirstSearch(graph,i,mp);
       }
   }

}

int main(){
    int v=6;
    vector<vector<int>> graph={{1,2},{4,3},{2,5},{5,6}};
    unordered_map<int,int>mp;
    for(int i=0;i<=6;i++){
        if(!mp[i])
            DepthFirstSearch(graph,i,mp);
    }
}
