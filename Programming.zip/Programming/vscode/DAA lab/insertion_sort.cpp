//insertion sort
#include <bits/stdc++.h>
using namespace std;

void print(vector<int> v){
    for(int i=0;i<v.size();i++){
        cout<<v[i]<<" ";
    }
    cout<<endl;
}

void insertion_sort(vector<int> &v){
    for(int i=1;i<v.size();i++){
        int j=i-1;
        int temp=v[i];
        while(j>=0 && v[j]>temp){
            v[j+1]=v[j];
            j--;
        }
        v[j+1]=temp;
    }
}

int main(){
    int n;
    cin >> n;
    vector<int> v;
    for(int i=0;i<n;i++){
        int x;
        cin >> x;
        v.push_back(x);
    }
    print(v);
    insertion_sort(v);
    print(v);
    cout<<endl;
    return 0;
}