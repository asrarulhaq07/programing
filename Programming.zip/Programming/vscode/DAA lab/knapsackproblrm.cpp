// 0 1 knapsack problem

#include<bits/stdc++.h>
using namespace std;

int knapsack(int wt[],int val[],int W,int n)
{
    if(n==0||W==0)
        return 0;
    if(wt[n-1]>W)
        return knapsack(wt,val,W,n-1);
    else
        return max(val[n-1]+knapsack(wt,val,W-wt[n-1],n-1),knapsack(wt,val,W,n-1));
}

int main()
{
    int n;
    cout<<"Enter the number of items: ";
    cin>>n;
    int wt[n],val[n];
    cout<<"Enter the weights of the items: ";
    for(int i=0;i<n;i++)
        cin>>wt[i];
    cout<<"Enter the values of the items: ";
    for(int i=0;i<n;i++)
        cin>>val[i];
    int W;
    cout<<"Enter the capacity of the knapsack: ";
    cin>>W;
    cout<<"Maximum value of the items that can be put in the knapsack: "<<knapsack(wt,val,W,n);
    return 0;
}