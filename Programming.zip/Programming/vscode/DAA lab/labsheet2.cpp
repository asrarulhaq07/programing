#include<bits/stdc++.h>
using namespace std;
void print(vector<int> v){
    for(int i=0;i<v.size();i++){
        cout<<v[i]<<" ";
    }
    cout<<endl;
}
void quickSort(vector<int> &a, int low, int high){
    if(low<high){
        int pivot = a[high];
        int i = low-1;
        for(int j=low;j<high;j++){
            if(a[j]<=pivot){
                i++;
                swap(a[i],a[j]);
            }
        }
        swap(a[i+1],a[high]);
        quickSort(a,low,i);
        quickSort(a,i+2,high);
    }
}

void insertionSort(vector<int> &a, int n){
    for(int i=1;i<n;i++){
        int key = a[i];
        int j = i-1;
        while(j>=0 && a[j]>key){
            a[j+1] = a[j];
            j--;
        }
        a[j+1] = key;
    }
}

int main(){
    int t=10;
    while(t-->0){
    vector<int> a;
    int n=rand()%30;
    cout<<"Size Of Array Is "<<n<<endl;
    cout<<"Array Before Sorting : ";
    for(int i=0;i<n;i++){
        int val=rand()%100;
        cout<<val<<" ";
        a.push_back(val);
    }cout<<endl;
    if(n<=10){
        cout<<"Using Insertion Sort"<<endl;
    insertionSort(a,n);
    }
    else{
        cout<<"Using Quick Sort"<<endl;
         quickSort(a,0,n-1);
    }
    cout<<"Array after Sorting: ";
    print(a);
    cout<<endl<<endl;
    }

    return 0;
}