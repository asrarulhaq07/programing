#include <bits/stdc++.h>
using namespace std;

void print_subsequence(int* arr, int* up, int* down, int n, int m, int ind)
{
    int f_up = 0;
    int f_down = 0;
    vector<int> v;

    if (m == up[ind]) {
        f_up = 1;
    }
    else {
        f_down = 1;
    }

    v.push_back(arr[ind]);
    for (int i = ind - 1; i >= 0; i--) {
        if (m == 1) {
            break;
        }
        if (f_down) {
            if (up[i] + 1 == m) {
                v.push_back(arr[i]);
                m = up[i];
                f_down = 0;
                f_up = 1;
            }
        }
        else if (f_up) {
            if (down[i] + 1 == m) {
                v.push_back(arr[i]);
                m = down[i];
                f_down = 1;
                f_up = 0;
            }
        }
    }
    for (int i = v.size() - 1; i >= 0; i--) {
        cout << v[i] << " ";
    }
    cout << endl;
}

void find_length(int* arr, int n)
{
    int up[n];
    int down[n];

    for (int i = 0; i < n; i++) {
        up[i] = 1;
        down[i] = 1;
    }

    for (int i = 1; i < n; i++) {
        for (int j = 0; j < i; j++) {
            if (arr[i] > arr[j]) {
                up[i] = max(up[i], down[j] + 1);
            }
            else if (arr[i] < arr[j]) {
                down[i] = max(down[i], up[j] + 1);
            }
        }
    }

    int m = 0;
    int ind = 0;

    for (int i = 0; i < n; i++) {
        int temp = max(up[i], down[i]);
        if (temp > m) {
            m = temp;
            ind = i;
        }
    }

    print_subsequence(arr, up, down, n, m, ind);
}

int main()
{
        int n;
    
        cout << "Enter the element number : ";
        cin >> n;
    
        int arr[n];
        cout << "Fill the array : ";
        for (int i = 0; i < n; i++) {
            cin >> arr[i];
        }
    
        cout << "Length of the subsequence : ";
        find_length(arr, n);
    
    return 0;
}
