//merge sort
#include <bits/stdc++.h>
using namespace std;

void print(vector<int> v){
    for(int i=0;i<v.size();i++){
        cout<<v[i]<<" ";
    }
    cout<<endl;
}

void merge(vector<int> &v,int s,int e,int mid){
    vector<int> v1(v.begin()+s,v.begin()+mid+1);
    vector<int> v2(v.begin()+mid+1,v.begin()+e+1);
    int i=0,j=0,k=s;
    while(i<v1.size() && j<v2.size()){
        if(v1[i]<v2[j]){
            v[k]=v1[i];
            i++;
        }
        else{
            v[k]=v2[j];
            j++;
        }
        k++;
    }
    while(i<v1.size()){
        v[k]=v1[i];
        i++;
        k++;
    }
    while(j<v2.size()){
        v[k]=v2[j];
        j++;
        k++;
    }
}
void merge_sort(vector<int> &v,int s,int e){
    if(s<e){
        int mid=(s+e)/2;
        merge_sort(v,s,mid);
        merge_sort(v,mid+1,e);
        merge(v,s,e,mid);
    }
}

int main(){
    int n;
    cin >> n;
    vector<int> v;
    for(int i=0;i<n;i++){
        int x;
        cin >> x;
        v.push_back(x);
    }
    print(v);
    merge_sort(v,0,n-1);
    print(v);
    cout<<endl;
    return 0;
}









