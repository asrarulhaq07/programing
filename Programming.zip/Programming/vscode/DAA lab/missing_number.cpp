//find missing number in array
// Time Complexity: O(log(min(m,n)))
// Space Complexity: O(1)
#include <bits/stdc++.h>
using namespace std;
void print(vector<int> v){
    for(int i=0;i<v.size();i++){
        cout<<v[i]<<" ";
    }
    cout<<endl;
}
int missingnumber(vector<int> &v1){
    int n=v1.size();
    int low=0,high=n-1;
    while(low<=high){
        int mid=(low+high)/2;
        if(v1[mid]!=mid+1 && v1[mid-1]==mid){
            return mid+1;
        }
        if(v1[mid]!=mid+1){
            high=mid-1;
        }
        else{
            low=mid+1;
        }
    }
    return -1;
}
int main()
{
    int n;
    cout<<"Enter the size of the array: ";
    cin >> n;
    vector<int> v1;
    cout<<"Enter the elements of array in sorted order: ";
    for(int i=0;i<n;i++)
    {
        int x;
        cin >> x;
        v1.push_back(x);
    }
    cout<<"The array is: "<<endl;
    print(v1);
    cout<<"The missing number is: "<<missingnumber(v1)<<endl;
    return 0;
}