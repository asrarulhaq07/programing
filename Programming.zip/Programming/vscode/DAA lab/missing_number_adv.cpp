#include<bits/stdc++.h>
using namespace std;

    int missingNumber(vector<int> &a, int n) 
    { 
        int i=0;
        while(i < n){
            int temp = a[a[i]-1];
            if(a[i] <= 0 || a[i] > n || i+1 == a[i] || temp == a[i]){
                i++;
                continue;
            }
            a[a[i]-1] = a[i];
            a[i] = temp;
            
        }
        for(i=0; i<n; i++){
            if(a[i] != i+1) return i+1;
        }
        return i+1;
    } 

int missingNumber(int arr[], int n);

int main() { 
    
        int n;
        cin>>n;
        vector<int> v;
        for(int i=0; i<n; i++){
            int c;
            cin>>c;
            v.push_back(c);
        }
        
        cout<<missingNumber(v, n)<<endl;
    return 0; 
}  