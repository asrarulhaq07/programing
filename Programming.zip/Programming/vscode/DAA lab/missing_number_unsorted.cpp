//find missing number in unsorted array
// Time Complexity: O(n)
// Space Complexity: O(1)
#include <bits/stdc++.h>
using namespace std;
void print(vector<int> v){
    for(int i=0;i<v.size();i++){
        cout<<v[i]<<" ";
    }
    cout<<endl;
}
int missingnumber(vector<int> &v1){
    int ans=0;
    for(int i=0;i<v1.size();i++){
        ans=ans^v1[i];
    }
    for(int i=1;i<=v1.size()+1;i++){
        ans=ans^i;
    }
    return ans;
}
int main()
{
    int n;
    cout<<"Enter the size of the array: ";
    cin >> n;
    vector<int> v1;
    cout<<"Enter the elements of array in unsorted order: ";
    for(int i=0;i<n;i++)
    {
        int x;
        cin >> x;
        v1.push_back(x);
    }
    cout<<"The array is: "<<endl;
    print(v1);
    cout<<"The missing number is: "<<missingnumber(v1)<<endl;
    return 0;
}