//optimal Binary search tree
#include<iostream>
#include<climits>
using namespace std;
int sum(int freq[],int i,int j)
{
    int s=0;
    for(int k=i;k<=j;k++)
        s+=freq[k];
    return s;
}
int OBST(int freq[],int i,int j)
{
    if(i>j)
        return 0;
    if(i==j)
        return freq[i];
    int fsum=sum(freq,i,j);
    int min=INT_MAX;
    for(int r=i;r<=j;r++)
    {
        int temp=OBST(freq,i,r-1)+OBST(freq,r+1,j);
        if(temp<min)
            min=temp;
    }
    return min+fsum;
}
int main()
{
    int n;
    cout<<"Enter the number of keys: ";
    cin>>n;
    int freq[n];
    cout<<"Enter the frequency of the keys: ";
    for(int i=0;i<n;i++)
        cin>>freq[i];
    cout<<"Minimum cost of the optimal binary search tree: "<<OBST(freq,0,n-1);
    return 0;
}