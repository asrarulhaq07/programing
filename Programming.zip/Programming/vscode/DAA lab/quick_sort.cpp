//quick sort
#include <bits/stdc++.h>
using namespace std;

void print(vector<int> v){
    for(int i=0;i<v.size();i++){
        cout<<v[i]<<" ";
    }
    cout<<endl;
}

void quick_sort(vector<int> &v,int s,int e){
    if(s>=e) return;
    int p=s;
    for(int i=s+1;i<=e;i++){
        if(v[i]<v[s]){
            swap(v[i],v[++p]);  
        }
    }
    swap(v[s],v[p]);
    quick_sort(v,s,p-1);
    quick_sort(v,p+1,e);
}
int main(){
    int n;
    cin>>n;
    vector<int> v(n);
    for(int i=0;i<n;i++){
        cin>>v[i];
    }
    print(v);
    quick_sort(v,0,n-1);
    print(v);
    return 0;
}