//selection sort
#include <bits/stdc++.h>
using namespace std;

void print(vector<int> v){
    for(int i=0;i<v.size();i++){
        cout<<v[i]<<" ";
    }
    cout<<endl;
}

void selection_sort(vector<int> &v){
    for(int i=0;i<v.size();i++){
        int min_index=i;
        for(int j=i+1;j<v.size();j++){
            if(v[j]<v[min_index]){
                min_index=j;
            }
        }
        swap(v[i],v[min_index]);
    }
}

int main(){

    int n;
    cin >> n;
    vector<int> v;
    for(int i=0;i<n;i++){
        int x;
        cin >> x;
        v.push_back(x);
    }
    print(v);
    selection_sort(v);
    print(v);
    return 0;
}