# inputs=[1.1,2.2,3.3]
# weights=[3.1,2.1,8.7]
# bias=3
# output=inputs[0]*weights[0]+inputs[1]*weights[1]+inputs[2]*weights[2]+bias
# print(output)


# inputs=[1.1,0.5,0.3]
# weights1=[0.1,0.2,0.3]
# weights2=[0.4,0.5,0.6]
# weights3=[0.7,0.8,0.9]
# bias1=0.1
# bias2=0.2
# bias3=0.3

# output=[[inputs[0]*weights1[0]+inputs[1]*weights1[1]+inputs[2]*weights1[2]+bias1],
# [inputs[0]*weights2[0]+inputs[1]*weights2[1]+inputs[2]*weights2[2]+bias2],
# [inputs[0]*weights3[0]+inputs[1]*weights3[1]+inputs[2]*weights3[2]+bias3]]
# print(output)



# inputs=[1.0,1.4,-1.4]

# weights=[[1.2,1.0,-0.4],[1.0,1.2,-0.5],[0.5,0.8,-0.3],[0.3,0.6,-0.2]]

# bias=[2,3,4]

# layer_output=[]

# for neuron_weights,neuron_bias in zip(weights,bias):
#     neuron_output=0
#     for n_input,weight in zip(inputs,neuron_weights):
#         # print(n_input,weight)
#         neuron_output+=n_input*weight
#     neuron_output+=neuron_bias
#     layer_output.append(neuron_output)

# print(layer_output)

# import numpy as np

# inputs=[1.0,1.4,-1.4]
# weights=[1.2,-0.5,0.3]
# bias=2
# output=np.dot(weights,inputs)+bias
# print(output)

# import numpy as np

# inputs=[1.2,2.3,3.4]
# weights=[[1.2,1.0,-0.4],
#         [1.0,1.2,-0.5],
#         [0.5,0.8,-0.3]]
# bias=[2,3,4]
# output=np.dot(weights,inputs)+bias
# print(output)

'''
inputs.weight gives shape error 
it is like y=mx+c that is output=weights*inputs+bias'''

# import numpy as np

# inputs=[[1,3.0,2.5,4.2],
#         [1.3,-2.2,3.4,1.2],
#         [0.5,1.2,3.4,2.1]]
# weights=[[2.1,1.2,3.4,2.5],
#         [1.2,2.3,4.5,1.2],
#         [1.2,2.3,4.5,1.2]]
# biases=[2,3,4]
# output=np.dot(inputs,np.array(weights).T)+biases
# print(output)
'''transposing weights to make it compatible with inputs'''