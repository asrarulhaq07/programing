# create web page which makes pdf to image
from flask import Flask, render_template, request, redirect, url_for 
from werkzeug.utils import secure_filename
import os
from wand.image import Image
import PyPDF2
from pdf2image import convert_from_path
import pytesseract
from PIL import Image as PI

app = Flask(__name__, static_url_path='', static_folder='media')
app.config['UPLOAD_FOLDER'] = './media'

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/uploadpdf', methods=['POST', 'GET'])
# upload pdf file
def uploadpdf():
    file_name = request.files['file']
    images=convert_from_path(file_name)
    i=1
    for image in images:
        image.save('page'+str(i)+'.jpg','JPEG')
        i+=1

    return render_template('uploadpdf.html')

@app.route('/uploadimage', methods=['POST'])
# upload image file
def uploadimage():
    return render_template('uploadimage.html')

# # get image file
# @app.route('/getimage', methods=['POST'])
# def getimage():
#         # return image file
#         return render_template('getimage.html')

# get ocr of image file




if __name__ == '__main__':
    app.run(debug=True)


