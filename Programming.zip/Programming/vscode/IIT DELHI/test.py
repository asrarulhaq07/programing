<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <style>
        body,
        html {
            height: 100%;
            font-family: Arial, Helvetica, sans-serif;
            overflow: hidden;
        }
        
        * {
            box-sizing: border-box;
        }
        
        .bg-img {
            /* The image used */
            background-image: url("https://images.unsplash.com/photo-1472289065668-ce650ac443d2?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=869&q=80");
            width: 100%;
            height: 100%;
            background-repeat: no-repeat;
            background-size: cover;
        }
        
        .btn {
            background-color: #4c06ee;
            color: white;
            margin-top: 12%;
            margin-inline-start: 30%;
            padding: 16px 20px;
            border: 1px solid black;
            cursor: pointer;
            width: 50%;
            opacity: 0.9;
        }
        
        .btn:hover {
            background-color: #06c0ee;
            opacity: 1;
        }
        
        .btn2 {
            background-color: #4c06ee;
            color: white;
            margin-top: 7%;
            margin-inline-start: 30%;
            padding: 16px 20px;
            border: 1px solid black;
            cursor: pointer;
            width: 50%;
            opacity: 0.9;
        }
        
        .btn2:hover {
            background-color: #06c0ee;
            opacity: 1;
        }
    </style>
</head>

<body>
    <div class="bg-img">
        <form action="/uploadpdf" class="container" method="post" enctype="multipart/form-data">
            <button type="button" class="btn btn-primary btn-lg btn-block">Submit PDF</button>
        </form>
        <form action="/uploadimage" class="container" method="post" enctype="multipart/form-data">
            <button type="button" class="btn2 btn-primary btn-lg btn-block">Submit IMAGE</button>
        </form>
    </div>

</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

</html>