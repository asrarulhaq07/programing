#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

// Value depend on System core
#define CORE 10

// Maximum matrix size
#define MAX 10

// Maximum threads is equal to total core of system
pthread_t thread[CORE * 2];
int mat_A[MAX][MAX], mat_B[MAX][MAX], sum[MAX][MAX], sub[MAX][MAX];

// Addition of a Matrix

pthread_mutex_t status;

typedef struct lock {
    pthread_mutex_t* status;
    int *mat_A;
} lock;

void* addition(void* arg)
{


    lock* l = (lock*)arg;
    pthread_mutex_t* status = l -> status;

    int k, j;
	int core = (int)arg;

	// Each thread computes 1/4th of matrix addition
	for (k = core * MAX / 10; k < (core + 1) * MAX / 10; k++) {

		for (j = 0; j < MAX; j++) {
            pthread_mutex_lock(status);
			// Compute Sum Row wise
			sum[k][j] = mat_A[k][j] + mat_B[k][j];
            pthread_mutex_unlock(status);
		}

	}
        
    return NULL;
}



// Driver Code
int main()
{
     int num;
    pthread_t tid[5];

    // Mutex Locked Increment
    printf("Locked Increment:\n");

    num = 0;

    lock l;
    pthread_mutex_init(&status, NULL);
    l.status = &status;
    l.mat_A = &addition;
	int i, j, step = 0;
	// Generating random values in mat_A and mat_B
	for (i = 0; i < MAX; i++) {

		for (j = 0; j < MAX; j++) {

			mat_A[i][j] = rand() % 10;
			mat_B[i][j] = rand() % 10;

		}

	}


	// Displaying mat_A
	printf("\nMatrix A:\n");

	for (i = 0; i < MAX; i++) {

		for (j = 0; j < MAX; j++) {

			printf("%d ", mat_A[i][j]);
		}

		printf("\n");
	}

	// Displaying mat_B
	printf("\nMatrix B:\n");

	for (i = 0; i < MAX; i++) {

		for (j = 0; j < MAX; j++) {

			printf("%d ", mat_B[i][j]);
		}

		printf("\n");
	}

	// Creating threads equal
	// to core size and compute matrix row
	for (i = 0; i < CORE; i++) {

		pthread_create(&tid[i], NULL, &addition, (void*)&l);
		step++;
	}

	// Waiting for join threads after compute
	for (i = 0; i < CORE * 2; i++) {

		pthread_join(tid[i], NULL);
	}

	// Display Addition of mat_A and mat_B
	printf("\n Sum of Matrix A and B:\n");

	for (i = 0; i < MAX; i++) {

		for (j = 0; j < MAX; j++) {

			printf("%d ", sum[i][j]);
		}

		printf("\n");
	}

	return 0;
}
