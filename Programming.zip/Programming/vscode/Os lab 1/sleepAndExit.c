#include <stdio.h>
//#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>

int main(){
    for(int i=0;i<10;i++){
        sleep(1);
        
        if(i>6){
            printf("\n i am line %d  and need to exit \n",i);
            exit(1);
        }
        printf("\n i am line %d \n",i);
    }
    return 0;
}