    // // execve
    // f = fork();
    // if (f == 0) {
    //     printf("execve --> ls -a\n");
    //     char* argument_list[] = {"ls", "-a", NULL};
    //     char* const env_list[] = {"A=BC", "D=EF", NULL};
    //     int status_code = execve("/bin/ls", argument_list, env_list);
    //     if (status_code == -1) {
    //         printf("Child process did not terminate correctly!\n");
    //         return 1;
    //     }
    // }
    // wait(NULL);