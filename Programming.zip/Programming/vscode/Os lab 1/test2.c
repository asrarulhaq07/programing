#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
  
lock l;
void* simple_increment(void* vargp) {
    int* num = (int*)vargp;
    
    for (int i = 0; i < 10000; i++) {
        *num = *num + 1;
    }

    return NULL;
}

pthread_mutex_t status;

typedef struct lock {
    pthread_mutex_t* status;
    int *num;
} lock;

void* locked_increment(void* vargp) {
    lock* l = (lock*)vargp;
    int* num = l -> num;
    pthread_mutex_t* status = l -> status;

    for (int i = 0; i < 10000; i++) {
        pthread_mutex_lock(status);
        *num = *num + 1;
        pthread_mutex_unlock(status);
    }

    return NULL;
}
// Value depend on System core
#define CORE 10
  
// Maximum matrix size
#define MAX 10
  
// Maximum threads is equal to total core of system
pthread_t thread[CORE * 2];
int mat_A[MAX][MAX], mat_B[MAX][MAX], sum[MAX][MAX], sub[MAX][MAX];
  
// Addition of a Matrix
void* addition(void* arg)
{
  
    int i, j;
    int core = (int)arg;
  
    // Each thread computes 1/10th of matrix addition
    for (i = core * MAX / 10; i < (core + 1) * MAX / 10; i++) {
  
        for (j = 0; j < MAX; j++) {
  
            // Compute Sum Row wise
            pthread_create(sum[i][j] = mat_A[i][j] + mat_B[i][j], NULL, locked_increment, (void*)&l);
            //sum[i][j] = mat_A[i][j] + mat_B[i][j];
        }
  
    }
  
}
  
  
// Subtraction of a Matrix
void* subtraction(void* arg)
{
  
    int i, j;
    int core = (int)arg;
  
    // Each thread computes 1/10th of matrix subtraction
    for (i = core * MAX / 10; i < (core + 1) * MAX / 10; i++) {
  
        for (j = 0; j < MAX; j++) {
  
            // Compute Subtract row wise 
            sub[i][j] = mat_A[i][j] - mat_B[i][j];
        }
  
    }
  
}
  
  
// Driver Code
int main()
{
  
    int num;
    pthread_t tid[5];
    num = 0;

    
    pthread_mutex_init(&status, NULL);
    l.status = &status;
    l.num = &num;

    for (int i=0; i<5; i++) {
        pthread_create(&tid[i], NULL, locked_increment, (void*)&l);
    }
    for (int i=0; i<5; i++) {
        pthread_join(tid[i], NULL);
    }

    int i, j, step = 0;
    // Generating random values in mat_A and mat_B
    for (i = 0; i < MAX; i++)  {
  
        for (j = 0; j < MAX; j++)  {
  
            mat_A[i][j] = rand() % 10;
            mat_B[i][j] = rand() % 10;
  
        }
  
    }
  
  
    // Displaying mat_A
    printf("\nMatrix A:\n");
  
    for (i = 0; i < MAX; i++) {
  
        for (j = 0; j < MAX; j++) {
  
            printf("%d ", mat_A[i][j]);
        }
  
        printf("\n");
    }
  
    // Displaying mat_B
    printf("\nMatrix B:\n");
  
    for (i = 0; i < MAX; i++) {
  
        for (j = 0; j < MAX; j++) {
  
            printf("%d ", mat_B[i][j]);
        }
  
        printf("\n");
    }
  
    // Creating threads equal
    // to core size and compute matrix row
    for (i = 0; i < CORE; i++) {
  
        pthread_create(&thread[i], NULL, &addition, (void*)step);
        pthread_create(&thread[i + CORE], NULL, &subtraction, (void*)step);
        step++;
    }
  
    // Waiting for join threads after compute
    for (i = 0; i < CORE * 2; i++) {
  
        pthread_join(thread[i], NULL);
    }
  
    // Display Addition of mat_A and mat_B
    printf("\n Sum of Matrix A and B:\n");
  
    for (i = 0; i < MAX; i++) {
  
        for (j = 0; j < MAX; j++) {
  
            printf("%d   ", sum[i][j]);
        }
  
        printf("\n");
    }
  
    // Display Subtraction of mat_A and mat_B
    printf("\n Subtraction of Matrix A and B:\n");
  
    for (i = 0; i < MAX; i++) {
  
        for (j = 0; j < MAX; j++) {
  
            printf("%d   ", sub[i][j]);
        }
  
        printf("\n");
    }
  
    return 0;
}