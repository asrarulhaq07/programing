# line segmentation of pdf file using python

# import the necessary packages
import numpy as np
import cv2
import os


image = cv2.imread('out.jpg')

# Convert the image to grayscale
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Apply thresholding to the image to create a binary image
thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)[1]

# Find the horizontal and vertical lines in the image
horizontal_lines = cv2.HoughLinesP(thresh, 1, np.pi/180, 100, minLineLength=100, maxLineGap=50)
vertical_lines = cv2.HoughLinesP(thresh, 1, np.pi/180, 100, minLineLength=100, maxLineGap=50)

# Create a copy of the image to draw the lines on
line_image = image.copy()

        # Draw the horizontal lines on the image
for line in horizontal_lines:
    x1, y1, x2, y2 = line[0]
    cv2.line(line_image, (x1, y1), (x2, y2), (255, 0, 0), 3)

        # Draw the vertical lines on the image
for line in vertical_lines:
    x1, y1, x2, y2 = line[0]
    cv2.line(line_image, (x1, y1), (x2, y2), (255, 0, 0), 3)

# save image as line_image+filename
cv2.imwrite('line_image.jpg', line_image)
