# import cv2
# import pytesseract

# # Load the image
# image = cv2.imread('image1.png')

# # Run Tesseract OCR on the image
# text = pytesseract.image_to_string(image)

# print(text)
import cv2
import pytesseract

# Load the image
image = cv2.imread('image1.png')

# Convert the image to grayscale
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Apply Otsu's thresholding to binarize the image
threshold, binarized = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

# Find all the contours in the binarized image
contours, hierarchy = cv2.findContours(binarized, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

# Iterate over the contours and extract the bounding boxes
for c in contours:
    x, y, w, h = cv2.boundingRect(c)
    cv2.rectangle(image, (x, y), (x + w, y + h), (0, 255, 0), 2)

    # Extract the ROI (region of interest) and run OCR on it
    roi = binarized[y:y + h, x:x + w]
    text = pytesseract.image_to_string(roi)
    print(text)

# Save the image with bounding boxes drawn on it
cv2.imwrite('text_image_boxes.jpg', image)