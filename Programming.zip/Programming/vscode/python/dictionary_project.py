d={"mutable":"liable to change",
"immutable":"unchanging over time or unable to be changed",
"hangover":"a severe headache or other after-effects caused by drinking an excess of alcohol."}
print("Enter the word")
inp=input()
print("the meaning of word",inp,"is",end=" ")
print(d[inp])
