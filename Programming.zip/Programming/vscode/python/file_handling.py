from turtle import pen

''' 
r=reading file----dafault
w=write in file
x=creating fle if it does not exist
a=append i.e adding more content to file
t=text mode
+=both read and write
b=binary mode
'''
# f = open("myfile.txt", "x")
# f.write("Hello World")
# f.close()

a= open("myfile.txt")
print(a.read())
a.close()

