# quiz game
def printfct(answer):
    num=[]
    num.append(answer)
    num.append(random.randint(1,19))
    num.append(random.randint(1,19))
    num.append(random.randint(1,19))
    random.shuffle(num)
    for i,j in zip(["A","B","C","D"],num):
        print(i,":",j)

import random
def main():
    print("Welcome to the quiz game!")
    print("You will be asked 10 questions.")
    print("You will be given 4 possible answers.")
    print("Please select the correct answer by typing the letter of the answer.")
    print("Good luck!")
    print()

    score = 0
    for i in range(10):
        num1 = random.randint(1, 10)
        num2 = random.randint(1, 10)
        answer = num1 + num2
        print("What is", num1, "+", num2, "?")
        
        printfct(answer)
        print()
        user_answer = input("Your answer: ")
        # user_answer = user_answer.upper()
        if (int(user_answer) ==answer):
            print("Correct!")
            score += 1
        else:
            print("Incorrect!")
        print()
    print("You got", score, "out of 10 questions correct.")
    print("Thank you for playing!")

main()
