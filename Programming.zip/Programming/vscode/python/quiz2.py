while(True):
    inp=int(input())
    if(inp>100):
        print("you have found way to exit loop")

    else:
        print("you are stuck inside loop try bigger number")
