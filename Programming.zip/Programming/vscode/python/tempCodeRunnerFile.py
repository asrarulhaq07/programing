content=f.read()
# # printing content
# print(content)
# f.close()