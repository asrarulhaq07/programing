#pdf merger

# from PyPDF2 import PdfFileMerger,PdfFileReader
# import os
# merger=PdfFileMerger()
# for items in os.listdir():
#     if items.endswith(".pdf"):
#         merger.append(items)
# merger.write("final_pdf.pdf")
# merger=PdfFileMerger()
# with open(originalFile, 'rb') as fin:
#     merger.append(PdfFileReader(fin))
# os.remove(originalFile)
# merger.close()

# lst = [3, 2, 0, 4]
 
# for n in lst:
#     if n != 2 and n != 4:
#         print(lst[n], end=" ")
# l = ['A', 1, 4, 2, (6, 5)]
# del l[:-3]
 
# print(l)
# lst = [-1, 0, 1, 2]
# print(lst[lst[0]])
# tpl = ('a', 'b', 'c', 'd')
# del tpl[-3:-1]
    # 
# print(tpl)
# lst = [x for x in range(4)]
# print(lst)


# x = input("Enter a number: ")
# print(x / 0)

# def factorial(x):
    # return x * factorial(x - 1)
#  
# num = 3
# print("The factorial of", num, "is", factorial(num))

# count = 0
# while count < 3:
#     print(count, end = ",")
# count += 1

# a = 1
# b = 10
 
# while a < b:
#     print("#")
#     a += 3

# def fun(x):
#     return x ** 2 + 1
 
# print(fun(fun(2)))

# tpl = ((1, 'one'), (2, 'two'))
# d=dict(tpl)
# print(d)


# s1 = 'Python'
# s2 = s1[0] + s1[-3] * len(s1)
# print(s2)
# 
# z = 1
# k = z * 2
# print(K % 2)

# lst = ['abc', 1, 1. + 2, True, (8, 9)]
 
# print(3.0 in lst)
# print('b' in lst)
# print(8 in lst)
# print(False not in lst)

# print(True > False)

# x = 10
#  
# def fun():
    # global x
    # if x >= 10:
        # x += 100
#  
# print(x)

# print(2 + 5.0 * 3)

# try:
#     x = int(input("Enter a first number: "))
#     y = int(input("Enter a second number: "))
 
#     print(x / y ** x)
 
# except ZeroDivisionError:
#     print("Division by zero is not allowed")
 
# except ValueError:
#     print("The value entered is incorrect")
 
# except:
#     print("An error occurred")

# def myFun(): 
#     x += 1.0        
 
# x = 5
# myFun(x)
 
# print(x)

# def fun(str1="Hello", str2="World!"):
#     print(str1, str2)
 
# fun(str2="Python!")


# a = False
# b = True
 
# x = a or b  
# y = a and b 
 
# print(x + (not y))

# x = "Monty" "Python"
# print(x)

# x=(1)
# print(type(x))

# print(4//3)

# x = 4
# y = x % 2
# print(x/y)

# val=input()
# print(type(val))

# def fun(x):
#     if x <= 0:        
#         return
#     else:
#         print(x * '#')
#         fun(x - 1)
 
# fun(2)

# a = 2, "w"
# b = {1 : 'x', 2 : 'y', 3 : 'z'}
# c = [(0, 1)]
# d = ('A', 4, 'Python')
 
# print(type(a))
# print(type(b))
# print(type(c))
# print(type(d))

# {1: 'one', 2: 'two', 3: 'three', 4: 'four'}



# d1 = {1: 'one', 2: 'two'}
# d2 = {3: 'three', 4: 'four'}
 
# # Insert code here
# d1.update(d2)
# print(d1)

# print('a' + 'z' * 3)

# x = 1
 
# for i in range(3):
#     x = x * i
 
# print(x)

# str = "Hello"
 
# for i in str:
#     if i != "o":
#         print(i)
# else:
#     print("World")


# n = 1
 
# while n < 4:    
#     n *= 2
# else:
#     print(n * 10)

# n = 10
 
# if n <= 10:
#     print('#', end="")
# if n > 0:
#     print('#', end="")
# elif n == 10:
#     print('#', end="")
# else:
#     print('#', end="")

# i = 6 % 2
 
# while i != 0:
#     print('A')
#     i = -1
# else:
#     print('B')
 
# print('C')

# x = 0
 
# if x == True:
#     print('A', end="")
 
# if x == 0.0:
#     print('B', end="")
 
# if x:
#     print('C', end="")

# print(2E3)


# a = 5
# b = 1
 
# x = a & b
# y = a | b
# z = a ^ b
 
# print(x + y + z)

# tpl = (5, 1, 3, 2)
# tpl[0] = tpl[1] + tpl[2]
 
# print(tpl)


# def myFun(n):
#     return
#     return n + 2 ** 3
 
# x = 2
# x = myFun(x)
# print(x)

# a = b = c = 2
# d = e = c = a + c
# f = g = e = e * c
 
# print(f / b)

# print(2 ** 2 ** 3 ** 0)

# x = 2
# y = 3
 
# x += y
# y *= x
# y /= 3
# x **= 2 
 
# print(y, x)

# d = {1: "A", 2: "H", 3: "C", 4: "B"}
 
# for i in sorted(d.values()):
#     print(i, end = " ")

# a, b = 2, 3
# a, b = b, a
 
# print(a * b ** a)


# test_results = {'Python': 77, 'C++': 69, 'Java': 81}
 
# for i in test_results.items():
#     print(i)

# x = 2	
# print(myFun(x))
 
# def myFun(n):        
#     return n * 3 + 1 

# def fun(x, y = 1):
#     return x * y
 
# print(fun('3', 2))

# x = int(3.5)
# y = str(3)
# z = float(0)
 
# print(x, y, z)


# t1 = 3
# t2 = 'a'
# t3 = (1, 2)
 
# t1, t2, t3 = t2, t3, t1
 
# print(t1, t2, t3)

# str = "XyZ"  
# c = "x"
 
# while c not in str:  
#     print("A")
#     break
# else:
#     print("B")


# tpl = (1, 2, 3, 4, 5)
 
# del tpl
 
# print(tpl)

# n = 0
 
# for i in "\'Monthy Python\'":
#     n += 1
 
# print(n)

# def sum(x, y, z=0):
#     print(x + y + z)

# print(list(range(-1, 3)))
# print(list(range(1, -3, -1)))
# print(list(range(1, 4.0)))


# lst = [[i * 2 for i in range(3)] for j in range(3)]
 
# x = 0
 
# for k in range(3):
#     x += lst[k][k] ** 2
 
# print(x)


# d1 = {1: 'one', 2: 'two', 3: 'three'}
 
# d2 = d1.copy()
# del d1
 
# print(d2)

# print(2 // 4)

# x = True
# y = False
 
# if x > y:
#     if y + 1:
#         print("A")
        
# if not x:
#     print("B")
# else:
#     print("C")


# n = 4
 
# while n > 0:
#   print("#")
#   n //= 2

# lst1 = [0, 3, 4, 6, 30]
# lst2 = []
 
# for n in range(len(lst1)):
#     if lst1[n] % 2 == 0 and lst1[n] % 3 == 0:
#         lst2.append(lst1[n])
    
# print(lst2)

# lst = [2, 3, 7, 11, 26]
 
# print(lst[::-1])

# d1 = {'Bob': 58}
# d2 = {'Tim': 56, 'Jane': 32}
# d3 = {'Liz': 51}
# d4 = {}
 
# for i in (d1, d2, d3):
#     d4.update(i)
 
# print(d4)

# def fun(a=3, b=7, c=2):
#     print(2 * b - a * c)
 
# fun()

# incipit = "It was \
# a dark and \
# stormy night"
 
# print(incipit)

# x = "Monty"
# y = "Python"
 
# print('x + y')

# lst = [1, 2, 3, 4, 5]
 
# lst.append([6, 7])
# lst.extend(['a', 'b'])
# lst.pop()
 
# print(lst)



# n = 5
 
# def fun(n = 1):
#     n += 3    
 
# fun(4)
# print(n)

# x = 1
 
# while x < 4:
#     x = x + 1
#     if x % 2 == 0:
#         pass
#     print("#")

# x = 2
# y = 1
# x = y
# y -= x
 
# print(y, x)

# tpl = ('a', True, 'Python', 1, [2, 3 ,4], ('five', 6))
 
# print(tpl[-len(tpl)], end=' ')  
 
# print(tpl[tpl[3]], end=' ')     
 
# print(tpl[2:-2], end=' ')

# for i in range(0, 5, 0):
#     print(i)




